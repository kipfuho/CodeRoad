Hướng dẫn sử dụng

Cách chạy: Chạy file ora3.html là được. Nếu được hãy chạy bằng server như 'Live server' trên Vscode, bạn sẽ không cần chọn file .ttf khi export sang PDF

Add Info Item:
- Bấm vào sẽ hiện ra một cửa sổ khác, cần chọn loại tương ứng, như Input sẽ có dạng văn bản và dạng Radio check box...
- Phần items dành cho input radio và select, hãy viết các lựa chọn bạn mong muốn và phân cách chúng bằng dấu chấm phẩy ; (ví dụ: chó;mèo)
- Chọn số lượng khối Info Item sẽ thêm, mặc định là 1
- Bấm add để xác nhận hoặc cancel để huỷ

Add Group Item:
- Thêm khối Group Item vào dưới khối được nhấn
- Mặc định không có khối Info Item được thêm vào

Item Info:
- Các chức năng như đề bài ORA3
- Click đúp vào 2 khối để thay đổi thông tin, Enter để lưu hoặc Esc để khôi phục lại trạng thái trước đó. Nếu lưu khi không có gì được điền sẽ khôi phục lại trạng thái ban đầu
- Với các khối radio hay select, hãy điền các lựa chọn như khi add Info Item; Với khối img thì có thêm nút 'Change image' để chọn ảnh
- Bấm vào icon thùng rác để xoá Info Item

Group Item:
- Các chức năng như đề bài
- Click đúp để thay đổi tên Group Item
- 2 nút add được trình bày phía trên
- Bấm vào icon thùng rác để xoá (từ Group Item thứ 2)

Export to PDF:
- Bấm vào icon PDF ở cạnh THÔNG TIN CÁ NHÂN để lưu các thông tin vào file PDF
- Khi bấm vào sẽ cần chọn file 'Roboto-Regular.ttf' được đính kèm bài nộp
- Trong trường hợp bạn chạy bằng server (http://... hoặc https://... Thay vì C:/.../ora3.html chẳng hạn) thì không cần chọn file .ttf
- File PDF được lưu dưới tên ttsv.pdf